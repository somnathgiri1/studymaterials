# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
rman target / NOCATALOG <<EOF
run {
restore datafile 1;
recover datafile 1;
alter database open;
}
EOF
