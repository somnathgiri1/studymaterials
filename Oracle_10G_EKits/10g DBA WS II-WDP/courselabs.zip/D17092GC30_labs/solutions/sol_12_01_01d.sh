# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
echo This script must be run as root.
/u01/app/oracle/product/10.2.0/db_1/bin/localconfig add
