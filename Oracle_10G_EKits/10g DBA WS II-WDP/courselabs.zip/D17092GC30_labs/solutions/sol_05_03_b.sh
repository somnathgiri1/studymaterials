# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
# MUSTEDIT
echo To run this, you must edit UNTIL TIME to be the
echo time that is one minute before the time returned
echo by the job_history query in the sol_05_03_a.sh script.

sqlplus / as sysdba <<EOF

SHUTDOWN IMMEDIATE
STARTUP MOUNT

EOF

export NLS_DATE_FORMAT="yyyy-mm-dd hh24:mi:ss"
export NLS_LANG=american_america.we8iso8859p15
rman target / NOCATALOG <<EOFRMAN
run {
set UNTIL TIME = 'put date-time here in this form: 2005-12-15 13:58:30';
RESTORE DATABASE;
RECOVER DATABASE;
ALTER DATABASE OPEN RESETLOGS;
}
EOFRMAN

