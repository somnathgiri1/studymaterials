# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
set echo on
ALTER SYSTEM SET sga_target='224395264' SCOPE=MEMORY;
ALTER SYSTEM SET db_cache_size='4194304' SCOPE=MEMORY;
ALTER SYSTEM SET java_pool_size='0' SCOPE=MEMORY;
ALTER SYSTEM SET large_pool_size='0' SCOPE=MEMORY;
ALTER SYSTEM SET shared_pool_size='0' SCOPE=MEMORY;
exit
EOF

