# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
set echo on
alter database open read only;
prompt The following result should be 691400.
SELECT SUM(salary) FROM hr.employees;
exit
EOF

