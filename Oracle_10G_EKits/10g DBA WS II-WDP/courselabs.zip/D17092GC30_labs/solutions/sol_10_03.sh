# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script gathers statistics for the HR.TEST_REGIONS table 
#   used for space monitoring labs.
#   Start this script connected as OS user: oracle.


sqlplus / as sysdba << EOF

begin

dbms_stats.gather_table_stats(
ownname=> 'HR',
tabname=> 'TEST_REGIONS' ,
estimate_percent=> DBMS_STATS.AUTO_SAMPLE_SIZE,
cascade=> DBMS_STATS.AUTO_CASCADE,
degree=> null,
no_invalidate=> DBMS_STATS.AUTO_INVALIDATE,
granularity=> 'AUTO',
method_opt=> 'FOR ALL COLUMNS SIZE AUTO');

end;
/
exit;
EOF
