# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the scheduler practice.
#   Start this script connected as OS user: oracle.

sqlplus hr/hr << EOF

set echo on

BEGIN
sys.dbms_scheduler.set_attribute( name => '"HR"."SESS_UPDATE_SCHED"', attribute => 'repeat_interval', value => 'FREQ=MINUTELY;INTERVAL=3');
sys.dbms_scheduler.set_attribute( name => '"HR"."SESS_UPDATE_SCHED"', attribute => 'start_date', value => to_timestamp_tz('2005-12-08 07:58:00 -8:00', 'YYYY-MM-DD HH24:MI:SS TZH:TZM'));
sys.dbms_scheduler.set_attribute( name => '"HR"."SESS_UPDATE_SCHED"', attribute => 'comments', value => 'Every three minutes');
END;
/
Prompt Wait for 3 minutes, the query the SESSION_HISTORY table


exit;
EOF