# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
# MUSTEDIT
echo You must edit this script for it to work
rman target / NOCATALOG <<EOF
FLASHBACK DATABASE TO SCN=put SCN from step 2 here;
EOF

