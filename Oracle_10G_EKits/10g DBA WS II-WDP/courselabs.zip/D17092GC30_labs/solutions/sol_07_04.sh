# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
dbv file=/u01/app/oracle/oradata/orcl/example01.dbf blocksize=8192
