-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--

ALTER SESSION SET NLS_SORT=BINARY;
SELECT * FROM words
ORDER BY fr_word;
