# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
DROP TABLESPACE tbsasmmig INCLUDING CONTENTS AND DATAFILES;
host rm $ORACLE_HOME/dbs/asmmig1.dbf
exit
EOF
