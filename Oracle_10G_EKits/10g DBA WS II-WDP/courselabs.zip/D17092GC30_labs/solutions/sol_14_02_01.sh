# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the scheduler practice.
#   Start this script connected as OS user: oracle.


sqlplus hr/hr << EOF

set echo on

BEGIN
sys.dbms_scheduler.create_job(
job_name => '"HR"."CREATE_LOG_TABLE_JOB"',
job_type => 'PLSQL_BLOCK',
job_action => 'begin
   execute immediate
   (''create table session_history(
     snap_time TIMESTAMP WITH LOCAL TIME ZONE, 
     num_sessions NUMBER)'');
end;',
start_date => systimestamp at time zone 'America/New_York',
job_class => 'DEFAULT_JOB_CLASS',
comments => 'Create the SESSION_HISTORY table',
auto_drop => FALSE,
enabled => TRUE);
END;
/

exit;
EOF
