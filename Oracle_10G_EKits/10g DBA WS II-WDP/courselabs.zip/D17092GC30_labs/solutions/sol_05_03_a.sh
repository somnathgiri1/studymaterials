# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***

sqlplus hr/hr <<EOF
set echo on
alter session set nls_date_format = "yyyy-mm-dd hh24:mi:ss";
select min(end_date) from job_history where end_date > sysdate - 60;

EOF

