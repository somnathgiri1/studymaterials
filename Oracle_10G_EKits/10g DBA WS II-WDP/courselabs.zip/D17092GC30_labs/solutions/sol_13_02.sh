# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the Resource Manager practice session.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba <<EOF

BEGIN
dbms_resource_manager.clear_pending_area();
dbms_resource_manager.create_pending_area();
dbms_resource_manager.update_plan_directive(
    plan => 'SYSTEM_PLAN',
    group_or_subplan => 'LOW_GROUP',
    new_comment => 'Other sessions at lowest priority',
    new_cpu_p1 => NULL, new_cpu_p2 => NULL, new_cpu_p3 => 40, new_cpu_p4 => NULL,
    new_cpu_p5 => NULL, new_cpu_p6 => NULL, new_cpu_p7 => NULL, new_cpu_p8 => NULL,
    new_parallel_degree_limit_p1 => NULL,
    new_active_sess_pool_p1 => NULL,
    new_queueing_p1 => NULL,
    new_switch_group => NULL,
    new_switch_time => NULL,
    new_switch_estimate => false,
    new_max_est_exec_time => NULL,
    new_undo_pool => NULL,
    new_max_idle_time => NULL,
    new_max_idle_blocker_time => NULL,
    new_switch_time_in_call => NULL
);
dbms_resource_manager.create_plan_directive(
    plan => 'SYSTEM_PLAN',
    group_or_subplan => 'APPUSER',
    comment => '',
    cpu_p1 => NULL, cpu_p2 => NULL, cpu_p3 => 60, cpu_p4 => NULL,
    cpu_p5 => NULL, cpu_p6 => NULL, cpu_p7 => NULL, cpu_p8 => NULL,
    parallel_degree_limit_p1 => NULL,
    active_sess_pool_p1 => NULL,
    queueing_p1 => NULL,
    switch_group => '',
    switch_time => NULL,
    switch_estimate => false,
    max_est_exec_time => NULL,
    undo_pool => NULL,
    max_idle_time => NULL,
    max_idle_blocker_time => NULL,
    switch_time_in_call => NULL
);
dbms_resource_manager.submit_pending_area();
END;
/
exit
EOF
