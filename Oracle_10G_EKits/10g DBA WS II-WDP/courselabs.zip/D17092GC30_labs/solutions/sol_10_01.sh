# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script drops and creates the HR.TEST_REGIONS table 
#   used for space monitoring labs.
#   Start this script connected as OS user: oracle.

$HOME/labs/lab_10_01.sh
