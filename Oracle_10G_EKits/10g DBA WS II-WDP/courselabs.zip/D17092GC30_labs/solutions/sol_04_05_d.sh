# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF

set echo on

ALTER DATABASE DROP LOGFILE MEMBER
'/u01/app/oracle/oradata/orcl/redo02b.log';

ALTER DATABASE ADD LOGFILE MEMBER
'/u01/app/oracle/oradata/orcl/redo02b.log'
TO GROUP 2;

exit
EOF
