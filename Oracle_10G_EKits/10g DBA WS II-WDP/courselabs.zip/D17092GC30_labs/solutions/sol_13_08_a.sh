# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the Resource Manager practice session.
#   Start this script connected as OS user: oracle.
#    Start a SQL*Plus session as system/oracle@orcl

sqlplus system/oracle@orcl 

