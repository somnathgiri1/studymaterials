# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the scheduler practice.
#   Start this script connected as OS user: oracle.

sqlplus hr/hr << EOF

set echo on

SELECT * 
FROM HR.SESSION_HISTORY
ORDER BY snap_time;

exit;
EOF
