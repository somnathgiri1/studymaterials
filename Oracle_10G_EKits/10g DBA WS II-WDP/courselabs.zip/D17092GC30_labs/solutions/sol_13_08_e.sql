-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
-- 
-- ***Training purposes only***
-- ***Not appropriate for production use***
-- 
-- To test consumer group mappings

SELECT schemaname, resource_consumer_group
FROM V$SESSION
WHERE schemaname not like 'SYS%'
/
