# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the scheduler practice.
#   Start this script connected as OS user: oracle.


sqlplus hr/hr << EOF

set echo on

BEGIN
DBMS_SCHEDULER.DROP_PROGRAM(
program_name=>'HR.LOG_SESS_COUNT_PRGM',
force=>TRUE);
END;
/
BEGIN
DBMS_SCHEDULER.DROP_SCHEDULE(
schedule_name=>'HR.SESS_UPDATE_SCHED',
force=>TRUE);
END;
/
BEGIN
DBMS_SCHEDULER.DROP_JOB(
job_name=>'HR.CREATE_LOG_TABLE_JOB',
force=>TRUE);
END;
/
BEGIN
DBMS_SCHEDULER.DROP_JOB(
job_name=>'HR.LOG_SESSIONS_JOB',
force=>TRUE);
END;
/
DROP TABLE hr.session_history PURGE;

exit;
EOF
