# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the practice: Implementing TDE
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF


set echo on

select table_name,column_name from dba_encrypted_columns;

select * from TDE_DBA.EMP_ENC;

exit;
EOF
