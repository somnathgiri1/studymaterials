# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the Resource Manager practice session.
#   Start this script connected as OS user: oracle.


sqlplus / as sysdba << EOF

BEGIN
 dbms_resource_manager.clear_pending_area();
 dbms_resource_manager.create_pending_area();

BEGIN
    dbms_resource_manager_privs.grant_switch_consumer_group(
        grantee_name => 'PM',
        consumer_group => 'APPUSER',
        grant_option => FALSE
    );
END;
BEGIN
    dbms_resource_manager_privs.grant_switch_consumer_group(
        grantee_name => 'PM',
        consumer_group => 'LOW_GROUP',
        grant_option => FALSE
    );
END;
BEGIN
    dbms_resource_manager_privs.grant_switch_consumer_group(
        grantee_name => 'PM',
        consumer_group => 'SYS_GROUP',
        grant_option => FALSE
    );
END;
dbms_resource_manager.submit_pending_area();
END;
/

exit;
EOF