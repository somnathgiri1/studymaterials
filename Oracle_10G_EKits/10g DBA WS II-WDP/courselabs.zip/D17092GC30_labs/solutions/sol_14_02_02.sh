# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the scheduler practice.
#   Start this script connected as OS user: oracle.


sqlplus hr/hr << EOF

set echo on

BEGIN
DBMS_SCHEDULER.CREATE_PROGRAM(
program_name=>'HR.LOG_SESS_COUNT_PRGM',
program_action=>'DECLARE
sess_count   NUMBER;
BEGIN
SELECT COUNT(*) INTO sess_count FROM V\$SESSION;
INSERT INTO session_history VALUES (systimestamp, sess_count);
COMMIT;
END;',
program_type=>'PLSQL_BLOCK',
number_of_arguments=>0,
comments=>'',
enabled=>TRUE);
END;
/

exit;
EOF
