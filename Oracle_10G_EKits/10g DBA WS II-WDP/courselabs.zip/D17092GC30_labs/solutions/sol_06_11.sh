# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
set echo on
select flashback_data / extract (minute from (end_time - begin_time) DAY TO SECOND)
from v\$flashback_database_stat;
exit
EOF
