
# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the practice: Implementing TDE
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF
set echo on

ALTER SYSTEM SET ENCRYPTION WALLET OPEN IDENTIFIED BY "ora1cle2";

exit;
EOF