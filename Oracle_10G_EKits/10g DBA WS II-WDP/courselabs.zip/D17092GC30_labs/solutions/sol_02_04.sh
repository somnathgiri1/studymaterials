# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
rman target / NOCATALOG <<EOF
configure retention policy to recovery window of 2 days;
exit
EOF
