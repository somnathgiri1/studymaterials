# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
prompt Wait while database is restarted
set echo on
shutdown immediate
startup pfile=$HOME/labs/init_sgalab.ora
exit
EOF
