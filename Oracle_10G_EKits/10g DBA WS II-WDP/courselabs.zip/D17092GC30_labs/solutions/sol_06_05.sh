# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
set echo on
SELECT current_scn FROM v\$database;
SELECT SUM(salary) FROM hr.employees;
SELECT COUNT(*) FROM hr.job_history;
exit
EOF
