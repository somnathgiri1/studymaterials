-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
set echo on
-- a
SELECT SYSDATE FROM dual;
-- b
ALTER SESSION SET NLS_DATE_FORMAT='DD-MON-YYYY HH:MI:SS';
SELECT SYSDATE FROM dual;
-- c
ALTER SESSION SET NLS_LANGUAGE=FRENCH;
SELECT SYSDATE FROM dual;
exit

