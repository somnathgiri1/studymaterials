# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
GRANT "CONNECT" TO "HR";
GRANT "DBA" TO "HR";
ALTER USER "HR" DEFAULT ROLE ALL;
EOF
