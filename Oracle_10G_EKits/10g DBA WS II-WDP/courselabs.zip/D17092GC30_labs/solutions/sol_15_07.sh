# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the practice: Implementing TDE
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

set echo on

alter tablespace TDE offline;

host strings /u01/app/oracle/product/10.2.0/db_1/dbs/tde1.dbf | more

alter tablespace tde online;

exit;
EOF