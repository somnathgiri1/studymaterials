-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
select sum(salary) from employees;
select count(*) from job_history where end_date > sysdate - 60;
