# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the practice: Implementing TDE
#   Start this script connected as OS user: oracle.

cp $ORACLE_HOME/network/admin/sqlnet.ora old_sqlnet.ora

cat $HOME/labs/walletlocation.ora >> $ORACLE_HOME/network/admin/sqlnet.ora
