# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
set echo on
@$HOME/labs/lab_08_04.sql
exit
EOF
tail -20 $ORACLE_BASE/admin/orcl/bdump/alert_orcl.log
