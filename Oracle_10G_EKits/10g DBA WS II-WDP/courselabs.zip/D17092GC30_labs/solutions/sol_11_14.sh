# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script modifies thresholds.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

exec DBMS_SERVER_ALERT.SET_THRESHOLD(-
9000,NULL,NULL,NULL,NULL,1,1,NULL,5,'TBSALERT');

exit;
EOF
