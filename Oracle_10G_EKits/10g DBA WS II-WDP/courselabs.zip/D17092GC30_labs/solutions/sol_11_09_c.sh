# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script displays space alerts
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

PROMPT  Wait for 10 minutes and see critical.

select reason, message_level
from dba_outstanding_alerts
where object_name='TBSALERT';

exit;
EOF
