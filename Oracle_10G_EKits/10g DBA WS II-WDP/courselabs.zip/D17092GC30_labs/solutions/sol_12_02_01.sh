# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
CREATE TABLESPACE tbsasmmig DATAFILE 'asmmig1.dbf' SIZE 10M;
exit
EOF
