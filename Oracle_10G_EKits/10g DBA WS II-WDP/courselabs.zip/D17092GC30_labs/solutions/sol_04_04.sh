# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
set echo on
ALTER TABLESPACE "TEMP" ADD TEMPFILE '/u01/app/oracle/oradata/orcl/temp02.dbf' SIZE 25M AUTOEXTEND ON NEXT 5M MAXSIZE 100M;

ALTER TABLESPACE TEMP DROP TEMPFILE '/u01/app/oracle/oradata/orcl/temp01.dbf';

exit
EOF
