# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script drops and creates the TBSALERT tablespace 
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

drop tablespace TBSALERT including contents and datafiles;

CREATE SMALLFILE TABLESPACE tbsalert
DATAFILE 'alert1.dbf' SIZE 120M
LOGGING
EXTENT MANAGEMENT LOCAL
SEGMENT SPACE MANAGEMENT AUTO;

exit;
EOF
