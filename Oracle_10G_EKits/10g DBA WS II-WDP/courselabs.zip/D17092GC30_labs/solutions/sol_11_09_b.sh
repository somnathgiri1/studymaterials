# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script displays space alerts
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

select sum(bytes) *100 /125829120
from dba_extents 
where tablespace_name='TBSALERT';

exit;
EOF
