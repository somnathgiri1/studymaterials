# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
$HOME/labs/lab_07_02.sh /u01/app/oracle/oradata/orcl/example01.dbf 49 8192
