sqlplus / as sysdba <<EOF
@$HOME/workshops/wlab_05.sql
EOF
sqlplus / as sysdba <<EOF2
startup
EOF2
