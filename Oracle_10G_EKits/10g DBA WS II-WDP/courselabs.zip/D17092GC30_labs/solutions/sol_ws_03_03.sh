# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
emctl stop dbconsole

emca -repos recreate <<EOF
orcl
1521
oracle
oracle
Y
EOF

emca -deconfig dbcontrol db <<EOF2
orcl
Y
EOF2

emca -config dbcontrol db <<EOF3
orcl
1521
oracle
oracle
oracle







oracle
Y
EOF3
