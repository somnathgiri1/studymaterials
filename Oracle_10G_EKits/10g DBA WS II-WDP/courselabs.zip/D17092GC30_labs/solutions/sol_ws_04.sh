# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
export ORACLE_PATH=$HOME/workshops
sqlplus / as sysdba @wlab_04.sql
