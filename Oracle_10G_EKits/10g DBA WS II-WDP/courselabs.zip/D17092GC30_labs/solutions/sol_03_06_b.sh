# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
rman target / NOCATALOG <<EOF
BACKUP AS COPY FORMAT 'sysaux01.cpy' TABLESPACE SYSAUX TAG=SYSAUX01;
exit
EOF
