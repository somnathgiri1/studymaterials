# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script shrinks space and displays the result of 53.8%.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

ALTER TABLE "SYS"."EMPLOYEES1" SHRINK SPACE;
ALTER TABLE "SYS"."EMPLOYEES2" SHRINK SPACE;
ALTER TABLE "SYS"."EMPLOYEES3" SHRINK SPACE;
 

select (select sum(bytes) 
        from dba_extents 
        where tablespace_name='TBSALERT')*100/125829120
from dual;

exit;
EOF
