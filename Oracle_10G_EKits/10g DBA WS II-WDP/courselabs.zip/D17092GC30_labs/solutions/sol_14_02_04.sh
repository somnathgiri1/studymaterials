# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the scheduler practice.
#   Start this script connected as OS user: oracle.

sqlplus hr/hr << EOF

set echo on
BEGIN
sys.dbms_scheduler.create_job(
job_name => '"HR"."LOG_SESSIONS_JOB"',
program_name => 'HR.LOG_SESS_COUNT_PRGM',
schedule_name => 'HR.SESS_UPDATE_SCHED',
job_class => 'DEFAULT_JOB_CLASS',
comments => 'Count sessions with HR.LOG_SESS_COUNT_PRGM',
auto_drop => FALSE,
enabled => FALSE);
sys.dbms_scheduler.set_attribute( name => '"HR"."LOG_SESSIONS_JOB"', attribute => 'logging_level', value => DBMS_SCHEDULER.LOGGING_FULL);
sys.dbms_scheduler.enable( '"HR"."LOG_SESSIONS_JOB"' );
END;
/
exit;
EOF
