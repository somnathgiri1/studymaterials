# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
export ORACLE_SID=+ASM
sqlplus / as sysdba <<EOF
SELECT name, state, type, total_mb, free_mb FROM V\$ASM_DISKGROUP;
exit
EOF


