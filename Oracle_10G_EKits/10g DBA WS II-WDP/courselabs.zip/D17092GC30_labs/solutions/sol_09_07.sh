# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
set echo on
CREATE SMALLFILE TABLESPACE "TBSADDM2" DATAFILE '/u01/app/oracle/oradata/orcl/tbsaddm2.dbf' SIZE 50M LOGGING EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;
exit
EOF
