# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
rman target / NOCATALOG <<EOF
BLOCKRECOVER DATAFILE 5 BLOCK 49, 50, 51, 52;
exit
EOF
