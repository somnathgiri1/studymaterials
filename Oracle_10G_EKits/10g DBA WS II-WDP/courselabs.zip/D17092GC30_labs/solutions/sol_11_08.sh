# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script displays tablespace space usage level at 60.1%
#   Start this script connected as OS user: oracle

sqlplus / as sysdba << EOF

select sum(bytes) *100 /125829120
from dba_extents
where tablespace_name='TBSALERT'
/

PROMPT  Please wait for 10 minutes and see the warning alert

select reason
from dba_outstanding_alerts
where object_name='TBSALERT';

exit;
EOF
