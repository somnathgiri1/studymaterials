# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script modifies alert thresholds.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

exec DBMS_SERVER_ALERT.SET_THRESHOLD(-
dbms_server_alert.tablespace_pct_full,-
dbms_server_alert.operator_ge,55,-
dbms_server_alert.operator_ge,70,-
1,1,NULL,-
dbms_server_alert.object_type_tablespace,'TBSALERT');

exit;
EOF
