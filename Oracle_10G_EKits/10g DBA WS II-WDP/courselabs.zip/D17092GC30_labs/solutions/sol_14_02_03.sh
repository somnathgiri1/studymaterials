# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the scheduler practice.
#   Start this script connected as OS user: oracle.


sqlplus hr/hr << EOF

set echo on

BEGIN
 DBMS_SCHEDULER.CREATE_SCHEDULE(
   schedule_name => 'SESS_UPDATE_SCHED',
   start_date => SYSTIMESTAMP,
   repeat_interval => 'FREQ=SECONDLY;INTERVAL=3',
   comments => 'Every three seconds');
END;
/

exit;
EOF
