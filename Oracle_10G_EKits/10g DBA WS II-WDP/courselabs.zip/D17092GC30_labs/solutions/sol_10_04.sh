# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script gathers reorganizes 2 HR objects. 
#   It is used for space monitoring labs.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

ALTER TABLE "HR"."TEST_REGIONS" MOVE;
BEGIN DBMS_STATS.GATHER_TABLE_STATS('"HR"', '"TEST_REGIONS"', estimate_percent=>NULL, cascade=>TRUE); END;
/

exit;
EOF
