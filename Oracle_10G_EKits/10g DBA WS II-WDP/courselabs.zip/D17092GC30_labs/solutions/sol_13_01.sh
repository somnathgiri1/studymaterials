# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the Resource Manager practice session.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

BEGIN
dbms_resource_manager.clear_pending_area();
dbms_resource_manager.create_pending_area();
dbms_resource_manager.create_consumer_group(consumer_group => 'APPUSER', comment => '', cpu_mth => 'ROUND-ROBIN');
dbms_resource_manager.submit_pending_area();
END;
/
exit;
EOF
