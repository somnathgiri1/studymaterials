# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script reports alert thresholds
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

select warning_value,critical_value
from dba_thresholds
where metrics_name='Tablespace Space Usage' and
      object_name is null;

exit;
EOF
