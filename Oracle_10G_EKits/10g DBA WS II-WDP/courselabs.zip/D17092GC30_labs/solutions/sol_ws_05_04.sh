# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
# MUSTEDIT
echo This must be edited to reflect the SCN+1
echo returned from the SCN query in step 3.

rman target / nocatalog <<EOF
run {
  SET UNTIL SEQUENCE <put SCN here> thread 1;
  RESTORE DATABASE;
  RECOVER DATABASE;
  ALTER DATABASE OPEN RESETLOGS;
}

EOF
