# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script reports alert history.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

select reason,resolution
from dba_alert_history
where object_name='TBSALERT';

exit;
EOF
