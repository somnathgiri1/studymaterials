# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
rman target / NOCATALOG <<EOF
SQL "ALTER TABLESPACE tbsasmmig OFFLINE";
BACKUP AS COPY TABLESPACE tbsasmmig FORMAT '+DGROUP1';
SWITCH TABLESPACE tbsasmmig TO COPY;
SQL "ALTER TABLESPACE tbsasmmig ONLINE";
exit
EOF

sqlplus / as sysdba <<EOF2
column file_name format a48
select tablespace_name, file_name from dba_data_files;
SELECT * FROM t2;
exit
EOF2
