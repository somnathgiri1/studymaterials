# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
prompt Sleeping for 2 minutes...
set echo on
exec dbms_lock.sleep(120);
@$HOME/labs/lab_09_11.sql
exit
EOF

