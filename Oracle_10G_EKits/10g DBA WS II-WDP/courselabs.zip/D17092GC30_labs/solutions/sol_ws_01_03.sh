# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
sqlplus / as sysdba <<EOF
set echo on
SHUTDOWN IMMEDIATE
STARTUP MOUNT
ALTER DATABASE ARCHIVELOG;
ALTER DATABASE FLASHBACK ON;
ALTER DATABASE OPEN;
exit
EOF
echo Database has been put into ARCHIVELOG mode.
echo Flashback Database has been enabled.
echo Finished.
