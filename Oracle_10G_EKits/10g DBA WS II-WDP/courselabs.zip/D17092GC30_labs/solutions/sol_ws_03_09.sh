# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
export ORACLE_SID=+ASM
sqlplus / as sysdba <<EOF
ALTER DISKGROUP DGROUP1 ADD DISK '/dev/raw/raw5' NAME DGROUP1_0004 SIZE 400 M;
exit
EOF
