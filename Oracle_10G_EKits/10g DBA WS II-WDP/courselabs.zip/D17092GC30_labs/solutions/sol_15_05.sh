# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
export ORACLE_PATH=$HOME/labs
$HOME/labs/lab_15_05.sh
