-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
connect sys/oracle as sysdba
set echo off
drop table hr.departments cascade constraints;
select * from hr.departments;
select * from hr.departments;
select * from hr.departments;
exit
