-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
REM Generates a UNIX script file that deletes
REM the USERS tablespace datafile and online redo logs.

connect / as sysdba

set echo off
set term off
set heading off
set feed off
alter system switch logfile;
alter system switch logfile;
shutdown abort
!rm /u01/app/oracle/oradata/orcl/users01.dbf
!rm /u01/app/oracle/oradata/orcl/*.log

exit

