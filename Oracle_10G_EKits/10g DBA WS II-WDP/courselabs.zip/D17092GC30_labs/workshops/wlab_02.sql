-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
REM Generates a UNIX script file that deletes
REM the SYSTEM tablespace datafile.

connect / as sysdba

set echo off
set term off
set heading off
set feed off

spool /home/oracle/workshops/wlab2.sh
SELECT 'rm ' || file_name 
FROM DBA_DATA_FILES
WHERE tablespace_name = 'SYSTEM';
spool off

!chmod +x /home/oracle/workshops/wlab2.sh
shutdown immediate
!/home/oracle/workshops/wlab2.sh
!rm /home/oracle/workshops/wlab2.sh
exit

