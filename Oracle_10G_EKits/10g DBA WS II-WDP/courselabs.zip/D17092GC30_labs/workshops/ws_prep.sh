# Shutdown the database
echo Shutting down the database...
sqlplus / as sysdba <<EOF
set echo on
shutdown immediate
EOF

# Clean out the FRA (not needed b/c this instanciation is gone)
echo Cleaning out the Flash Recovery Area...
rm -rf $ORACLE_BASE/flash_recovery_area/ORCL/flashback/*
rm -rf $ORACLE_BASE/flash_recovery_area/ORCL/backupset/*
rm -rf $ORACLE_BASE/flash_recovery_area/ORCL/autobackup/*
rm -rf $ORACLE_BASE/flash_recovery_area/ORCL/archivelog/*

mkdir ~/DONTTOUCH/GONE

# Move the current datafiles out
echo Moving the current datafiles out...
mv $ORACLE_BASE/oradata/orcl/*.* ~/DONTTOUCH/GONE

# Copy baseline datafiles in
echo Copying baseline datafiles in...
cp ~/DONTTOUCH/*.* $ORACLE_BASE/oradata/orcl

# Startup the database
echo Starting the instance...
sqlplus / as sysdba <<EOF
set echo on
startup
EOF

echo Finished.



