-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
-- 
-- ***Training purposes only***
-- ***Not appropriate for production use***
-- 
-- Start a SQL*Plus session as system/oracle@orcl
-- Start a second SQL*Plus session to view information about

SELECT schemaname, resource_consumer_group
FROM V$SESSION
WHERE schemaname not like 'SYS%'
/
