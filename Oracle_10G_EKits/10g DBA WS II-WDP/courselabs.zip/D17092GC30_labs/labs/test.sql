-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
declare
t number;
begin
for t in 1..4444 loop
insert into addm values (Null,'a');
commit;
end loop;
end;
/
exit
