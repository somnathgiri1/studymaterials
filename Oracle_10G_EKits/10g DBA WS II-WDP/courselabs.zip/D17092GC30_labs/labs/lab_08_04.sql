-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
PROMPT *** Current parameter settings ***
col name format a12
col value format a8
show parameter sga_
PROMPT
PROMPT *** SGA Dynamic Component Size Information***
col component format a22
col current_size format a15
col min_size format a15

SELECT component,current_size/1048576||'M' current_size,
       min_size/1048576||'M' min_size
FROM v$sga_dynamic_components
WHERE component IN ('shared pool','large pool',
                   'java pool','DEFAULT buffer cache');

col name format a20
col value format a20
PROMPT *** Current parameter settings in V$PARAMETER *** 

SELECT name, value, isdefault 
FROM v$parameter
WHERE name IN ('shared_pool_size','large_pool_size',
               'java_pool_size', 'db_cache_size');

