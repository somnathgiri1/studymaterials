-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- For scheduler practice
BEGIN
   execute immediate
   (''create table session_history(
     snap_time TIMESTAMP WITH LOCAL TIME ZONE, 
     num_sessions NUMBER)'');
END;
