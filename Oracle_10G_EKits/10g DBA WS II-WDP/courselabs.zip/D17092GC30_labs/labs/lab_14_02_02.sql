-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- For scheduler practice

DECLARE
  sess_count   NUMBER;
BEGIN
 SELECT COUNT(*) INTO sess_count FROM V$SESSION;
 INSERT INTO session_history VALUES (systimestamp, sess_count);
COMMIT;
END;
