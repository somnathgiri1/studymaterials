# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script generates rows
#   to provide input for the growth trend reprt.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

drop sequence test_seq;

create sequence test_seq;

BEGIN
 FOR i in 1..1000 LOOP
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'10');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'20');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'30');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'40');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'50');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'60');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'70');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'80');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'90');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'00');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'11');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'21');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'31');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'41');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'51');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'61');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'71');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'81');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'91');
   insert into hr.test_regions values (test_seq.nextval, 'Test region '||'01');
   commit;   
 END LOOP;
END;
/
list
SELECT COUNT(*) FROM hr.test_regions;

delete from hr.test_regions
where region_name like '%20';
list
delete from hr.test_regions
where region_name like '%41';
list
delete from hr.test_regions
where region_name like '%60';
list
commit;

exit;
EOF
