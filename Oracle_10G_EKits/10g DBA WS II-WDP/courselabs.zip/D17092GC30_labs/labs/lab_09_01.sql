-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
set echo on
CREATE SMALLFILE TABLESPACE "TBSADDM" DATAFILE '/u01/app/oracle/oradata/orcl/tbsaddm.dbf' SIZE 50M LOGGING EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT MANUAL;

CREATE USER "ADDM" PROFILE "DEFAULT" IDENTIFIED BY addm DEFAULT TABLESPACE "TBSADDM" TEMPORARY TABLESPACE "TEMP" ACCOUNT UNLOCK;
GRANT CREATE SESSION TO "ADDM";
GRANT "DBA" TO "ADDM";
GRANT "RESOURCE" TO "ADDM";
