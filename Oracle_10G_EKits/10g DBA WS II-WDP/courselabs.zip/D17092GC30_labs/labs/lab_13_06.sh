# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the Resource Manager practice session.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

alter user hr identified by hr account unlock;
alter user scott identified by scott account unlock;
alter user oe identified by oe account unlock;
alter user pm identified by pm account unlock;

exit;
EOF


