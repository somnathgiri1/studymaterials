# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script generates rows to activate space alerts
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

insert into employees4 select * from employees4;
commit; 

insert into employees5 select * from employees5;
commit; 

exit;
EOF
