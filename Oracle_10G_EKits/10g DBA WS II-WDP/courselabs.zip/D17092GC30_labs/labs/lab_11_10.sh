# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script deletes rows and allocates extents.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

delete employees1 where department_id=50; 
commit;

delete employees2 where department_id=50; 
commit;

delete employees3 where department_id=50; 
commit;

alter table employees1 allocate extent (size 5M);
alter table employees2 allocate extent (size 5M);
alter table employees3 allocate extent (size 5M);

exit;
EOF
