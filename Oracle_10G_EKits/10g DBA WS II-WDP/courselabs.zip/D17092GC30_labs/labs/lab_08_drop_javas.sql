-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- This scripts creates many java stored procedures
-- in the HR schema.

connect hr/hr
set echo on
DECLARE
i NUMBER;
v_sql VARCHAR2(200);
BEGIN
  FOR i IN 1..200 LOOP
    v_sql := 'drop java source"SmallJavaProc' || i || '"';
    EXECUTE immediate v_sql;
  end loop;
end;
/
