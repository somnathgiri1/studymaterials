# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This calls a script that creates the DBA1 oracle user.
sqlplus -S /nolog @lab_05_01.sql
