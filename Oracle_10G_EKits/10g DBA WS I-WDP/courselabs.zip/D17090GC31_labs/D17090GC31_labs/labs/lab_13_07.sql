-- Oracle Database 10g: Administration Workshop I
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Attempts to turn on traceonly option of autotrace and
-- explain a query.

select * from hr.employees where employee_id = 201
/
