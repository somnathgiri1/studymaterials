# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#

sqlplus / as sysdba <<EOF
ALTER INDEX "HR"."EMP_NAME_IX" REBUILD;
BEGIN DBMS_STATS.GATHER_INDEX_STATS('"HR"', '"EMP_NAME_IX"', estimate_percent=>NULL); END;
/
ALTER INDEX "HR"."EMP_MANAGER_IX" REBUILD;
BEGIN DBMS_STATS.GATHER_INDEX_STATS('"HR"', '"EMP_MANAGER_IX"', estimate_percent=>NULL); END;
/
ALTER INDEX "HR"."EMP_JOB_IX" REBUILD;
BEGIN DBMS_STATS.GATHER_INDEX_STATS('"HR"', '"EMP_JOB_IX"', estimate_percent=>NULL); END;
/
ALTER INDEX "HR"."EMP_EMP_ID_PK" REBUILD;
BEGIN DBMS_STATS.GATHER_INDEX_STATS('"HR"', '"EMP_EMP_ID_PK"', estimate_percent=>NULL); END;
/
ALTER INDEX "HR"."EMP_EMAIL_UK" REBUILD;
BEGIN DBMS_STATS.GATHER_INDEX_STATS('"HR"', '"EMP_EMAIL_UK"', estimate_percent=>NULL); END;
/
ALTER INDEX "HR"."EMP_DEPARTMENT_IX" REBUILD;
BEGIN DBMS_STATS.GATHER_INDEX_STATS('"HR"', '"EMP_DEPARTMENT_IX"', estimate_percent=>NULL); END;
/
EOF
