# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script creates the HRCLERK role

sqlplus dba1/oracle as sysdba <<EOF
create role hrclerk;
grant select on hr.employees to hrclerk;
grant update on hr.employees to hrclerk;
exit
EOF





