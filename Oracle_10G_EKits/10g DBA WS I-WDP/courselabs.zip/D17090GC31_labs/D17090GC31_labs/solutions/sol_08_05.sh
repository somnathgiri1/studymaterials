# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
export ORACLE_PATH=/home/oracle/labs
sqlplus / as sysdba <<EOF
declare
sess varchar2(20);
sql_str varchar2(100);
begin
  select 'alter system kill session ''' || sid || ',' || serial# || ''' immediate'
    into sql_str from v\$session
    where username = 'NGREENBERG';
  execute immediate sql_str;
end;
/
EOF
