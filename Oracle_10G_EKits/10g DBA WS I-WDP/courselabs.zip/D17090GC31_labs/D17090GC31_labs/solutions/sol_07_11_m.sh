# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
sqlplus dba1/oracle <<EOF
create index inventory.code_func on inventory.product_master (upper(substr(code,5,2)));
quit
EOF
exit
