# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script changes the RESOURCE_LIMIT parameter

sqlplus dba1/oracle as sysdba <<EOF
ALTER SYSTEM SET resource_limit = TRUE SCOPE=MEMORY;
exit
EOF





