# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
#***Not appropriate for production use***
#
# Start this script as OS user: oracle
#   This script starts auditing DML statements on the HR.JOBS table

sqlplus / as sysdba << EOF

ALTER SYSTEM SET AUDIT_TRAIL="XML" SCOPE=SPFILE;

exit;
EOF
