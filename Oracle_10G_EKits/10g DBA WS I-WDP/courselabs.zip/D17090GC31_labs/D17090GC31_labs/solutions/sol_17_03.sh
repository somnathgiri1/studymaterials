# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
sqlplus dba1/oracle as sysdba <<EOF
flashback table hr.departments2 to before drop;
select count(*) from hr.departments2;
quit
EOF
exit
