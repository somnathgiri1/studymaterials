# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
sqlplus / as sysdba <<EOF
CREATE SMALLFILE TABLESPACE "INVENTORY" DATAFILE '/u01/app/oracle/oradata/ORCL/datafile/inventory01.dbf' SIZE 5M REUSE LOGGING EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO
/
quit
EOF



