# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
sqlplus dba1/oracle <<EOF
create index inventory.poh_prod_id_qty on 
inventory.product_on_hand(product_id, quantity);
quit
EOF
exit
