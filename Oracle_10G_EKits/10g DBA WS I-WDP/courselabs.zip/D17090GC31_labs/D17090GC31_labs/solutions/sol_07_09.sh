# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
sqlplus dba1/oracle <<EOF
drop table inventory.obsolete_products cascade constraints;
alter table inventory.product_master add (obsoleted date);
quit
EOF
exit
