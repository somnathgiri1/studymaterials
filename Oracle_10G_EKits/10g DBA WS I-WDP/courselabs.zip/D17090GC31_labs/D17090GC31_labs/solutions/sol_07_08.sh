# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
sqlplus dba1/oracle <<EOF
alter table inventory.product_master add (primary_source varchar2(50), secondary_source varchar2(50));
quit
EOF
exit
