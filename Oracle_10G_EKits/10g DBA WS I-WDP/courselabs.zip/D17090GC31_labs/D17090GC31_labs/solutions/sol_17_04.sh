# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
export ORACLE_PATH=/home/oracle/labs
sqlplus dba1/oracle as sysdba <<EOF
@lab_17_04.sql
quit
EOF
exit
