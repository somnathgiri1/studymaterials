# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
export ORACLE_PATH=/home/oracle/labs
sqlplus / as sysdba <<EOF
set serveroutput on
declare
sql_str varchar2(500);
begin
  select 'alter database datafile ''' || file_name || ''' resize 400M'
    into sql_str
    from dba_data_files where tablespace_name = 'UNDOTBS1';
  dbms_output.put_line(sql_str);
  execute immediate sql_str;
  select 'alter database datafile ''' || file_name || ''' autoextend off'
    into sql_str
    from dba_data_files where tablespace_name = 'UNDOTBS1';
  dbms_output.put_line(sql_str);
  execute immediate sql_str;
end;
/
