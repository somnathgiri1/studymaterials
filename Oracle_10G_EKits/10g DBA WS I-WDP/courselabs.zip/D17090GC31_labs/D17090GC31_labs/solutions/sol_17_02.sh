# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
sqlplus dba1/oracle as sysdba <<EOF
drop table hr.departments2;
select * from hr.departments2;
quit
EOF
exit
