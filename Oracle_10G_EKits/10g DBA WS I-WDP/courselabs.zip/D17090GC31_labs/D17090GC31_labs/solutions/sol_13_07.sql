set autotrace traceonly explain
connect hr/hr
select * from hr.employees where employee_id = 201;
