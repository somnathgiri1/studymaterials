# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#

sqlplus / as sysdba <<EOF
alter system set log_archive_dest_1 = "LOCATION=/u01/app/oracle/archive/ OPTIONAL REOPEN=300" SCOPE=BOTH;
alter system set log_archive_dest_10 = "LOCATION=USE_DB_RECOVERY_FILE_DEST OPTIONAL REOPEN=300" SCOPE=BOTH;
shutdown immediate
startup nomount
alter database mount;
alter database archivelog;
alter database open;
quit
EOF


