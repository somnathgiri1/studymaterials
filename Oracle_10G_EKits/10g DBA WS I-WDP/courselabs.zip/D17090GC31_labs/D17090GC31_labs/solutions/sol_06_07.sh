# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script creates the RPANDYA user and assigns the HRCLERK role

sqlplus dba1/oracle as sysdba <<EOF
DROP USER RPANDYA CASCADE;
create user rpandya identified by newuser profile hrprofile password expire;
grant connect, hrclerk to rpandya;
exit
EOF





