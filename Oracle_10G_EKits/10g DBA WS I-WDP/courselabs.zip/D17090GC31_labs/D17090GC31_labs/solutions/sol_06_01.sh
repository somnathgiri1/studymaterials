# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script creates the HRPROFILE profile

export ORACLE_PATH=~/labs
../labs/lab_06_01.sh
