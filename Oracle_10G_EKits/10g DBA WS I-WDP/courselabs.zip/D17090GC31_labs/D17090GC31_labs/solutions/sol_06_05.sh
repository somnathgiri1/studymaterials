# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script creates the HRMANAGER role

sqlplus dba1/oracle as sysdba <<EOF
create role hrmanager;
grant insert on hr.employees to hrmanager;
grant delete on hr.employees to hrmanager;
grant hrclerk to hrmanager;
exit
EOF





