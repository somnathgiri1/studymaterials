# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# Start this script as OS user: oracle
#   This script deletes all audit files

rm -f /u01/app/oracle/admin/orcl/adump/*
echo Audit trail directory is now clean.



