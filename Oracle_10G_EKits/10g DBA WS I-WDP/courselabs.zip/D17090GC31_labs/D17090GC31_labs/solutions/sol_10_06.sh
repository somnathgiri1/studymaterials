# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
#***Not appropriate for production use***
#
# Start this script as OS user: oracle
#   This script DISABLES AUDITING, THEN stops and restarts the database

sqlplus / as sysdba << EOF

NOAUDIT DELETE ON HR.JOBS;
NOAUDIT INSERT ON HR.JOBS;
NOAUDIT UPDATE ON HR.JOBS;

alter system set audit_trail="NONE" SCOPE=SPFILE;

shutdown immediate

startup

exit;
EOF
