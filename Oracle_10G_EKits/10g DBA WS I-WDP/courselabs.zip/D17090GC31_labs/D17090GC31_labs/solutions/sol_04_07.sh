# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
echo ---
echo This shows the 2 stages the database went
echo through during startup:
tail -50 $ORACLE_BASE/admin/orcl/bdump/alert_orcl.log | grep "Completed: ALTER DATABASE"
