# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
sqlplus dba1/oracle <<EOF
CREATE TABLE INVENTORY.PRODUCT_ON_HAND
(
PRODUCT_ID NUMBER(7),
QUANTITY NUMBER(5),
WAREHOUSE_CITY VARCHAR2(30),
LAST_UPDATE DATE,
  CONSTRAINT FK_PROD_ON_HAND_PROD_ID
    FOREIGN KEY (product_id) REFERENCES
    INVENTORY.PRODUCT_MASTER (PRODUCT_ID) VALIDATE
);
quit
EOF
exit
