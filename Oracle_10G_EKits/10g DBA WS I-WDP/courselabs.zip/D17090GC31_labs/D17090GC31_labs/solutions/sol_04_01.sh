# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
echo ---
echo This shows the 
echo Enterprise Manager Console HTTP Port
echo ---
cat <$ORACLE_HOME/install/portlist.ini
exit


