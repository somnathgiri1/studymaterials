-- Oracle Database 10g: Administration Workshop I
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
prompt This script performs catch up steps for practice 6
prompt Create profile: HRPROFILE
prompt Create roles: HRCLERK and HRMANAGER
prompt Create users: DHAMBY, RPANDYA and JGOODMAN 

CONNECT dba1/oracle as sysdba

ALTER SYSTEM SET resource_limit = TRUE SCOPE=MEMORY;

drop user dhamby cascade;
drop user rpandya cascade;
drop user jgoodman cascade;

drop profile hrprofile;

drop role hrmanager;
drop role hrclerk;

create profile hrprofile limit idle_time 15;

create role hrclerk;
grant select on hr.employees to hrclerk;
grant update on hr.employees to hrclerk;

create role hrmanager;
grant insert on hr.employees to hrmanager;
grant delete on hr.employees to hrmanager;
grant hrclerk to hrmanager;


create user dhamby identified by newuser 
profile hrprofile password expire;
grant connect, hrclerk to dhamby;

create user rpandya identified by newuser 
profile hrprofile password expire;
grant connect, hrclerk to rpandya;

create user jgoodman identified by newuser 
profile hrprofile password expire;
grant connect, hrmanager to jgoodman;

alter user dhamby identified by oracle;
alter user jgoodman identified by oracle;
alter user rpandya identified by oracle;

quit



