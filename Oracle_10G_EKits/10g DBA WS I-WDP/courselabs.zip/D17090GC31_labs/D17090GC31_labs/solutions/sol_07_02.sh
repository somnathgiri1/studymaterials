# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
sqlplus dba1/oracle <<EOF
CREATE TABLE "INVENTORY"."PRODUCT_MASTER" ( "PRODUCT_ID" NUMBER(7), "PRODUCT_NAME" VARCHAR2(50) NOT NULL , "CODE" VARCHAR2(10) NOT NULL , "REORDER_THRESHOLD" NUMBER(5), "COST" NUMBER(5, 2), "PRICE" NUMBER(5, 2), CONSTRAINT "PK_INV" PRIMARY KEY ("PRODUCT_ID") VALIDATE , CONSTRAINT "CHK_GT_0" CHECK (reorder_threshold > 0) VALIDATE ) TABLESPACE "INVENTORY";
quit
EOF
exit
