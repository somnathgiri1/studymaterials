# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
sqlplus / as sysdba <<EOF
set termout on
alter system set job_queue_processes = 15 scope = memory;
quit
EOF
exit
