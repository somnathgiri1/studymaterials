# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#

export ORACLE_PATH=/home/oracle/labs
rman target / <<EOF
backup incremental level 0 cumulative device type disk database include current controlfile;
exit
EOF
