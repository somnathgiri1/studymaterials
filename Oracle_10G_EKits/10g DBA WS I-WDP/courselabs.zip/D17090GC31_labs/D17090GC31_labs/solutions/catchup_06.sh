# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
export ORACLE_PATH=~/labs
sqlplus /nolog @catchup_06.sql
../labs/lab_06_01.sh
echo Catch up  for practice 6 completed
