# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#

./sol_05_01.sh
./sol_05_04.sh
./sol_05_06.sh
