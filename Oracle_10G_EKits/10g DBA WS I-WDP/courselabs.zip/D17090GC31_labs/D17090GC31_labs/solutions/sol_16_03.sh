# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#

export ORACLE_PATH=~/labs
sqlplus / as sysdba @lab_16_04.sql
