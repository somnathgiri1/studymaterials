# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#

./sol_07_02.sh
./sol_07_03.sh
./sol_07_04.sh
./sol_07_05.sh
./sol_07_06.sh
./sol_07_07.sh
./sol_07_08.sh
./sol_07_09.sh
./sol_07_10.sh
./sol_07_11_a.sh
./sol_07_11_b.sh
./sol_07_11_m.sh
./sol_07_11_p.sh

