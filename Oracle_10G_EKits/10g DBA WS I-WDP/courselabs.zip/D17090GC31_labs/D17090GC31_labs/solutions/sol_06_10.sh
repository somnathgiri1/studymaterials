# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script changes the password for the JGOODMAN user

sqlplus dba1/oracle as sysdba <<EOF
alter user jgoodman identified by oracle;
exit
EOF





