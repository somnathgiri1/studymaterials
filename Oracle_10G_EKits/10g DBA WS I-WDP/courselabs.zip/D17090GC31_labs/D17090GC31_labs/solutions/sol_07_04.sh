# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
sqlplus dba1/oracle <<EOF
CREATE TABLE "INVENTORY"."OBSOLETE_PRODUCTS" AS select product_id, product_name, code, cost, price
from inventory.product_master;
quit
EOF
exit
