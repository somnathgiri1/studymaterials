# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
export ORACLE_PATH=~/labs
sqlplus dba1/oracle <<EOF
alter database datafile
'/u01/app/oracle/oradata/ORCL/datafile/inventory01.dbf' resize 50M
/
EOF


