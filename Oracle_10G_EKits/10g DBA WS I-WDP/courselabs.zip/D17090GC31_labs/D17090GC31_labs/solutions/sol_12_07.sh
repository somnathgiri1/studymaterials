# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#

export ORACLE_PATH=~/labs
sqlplus / as sysdba <<EOF
CREATE SMALLFILE TABLESPACE "TBSADDM2" DATAFILE '/u01/app/oracle/oradata/ORCL/datafile/addm2_1.dbf' SIZE 50M LOGGING EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;
quit
EOF
../labs/lab_12_07.sh
