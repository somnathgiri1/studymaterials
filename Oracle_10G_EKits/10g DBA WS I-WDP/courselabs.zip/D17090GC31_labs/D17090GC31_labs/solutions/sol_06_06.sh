# Oracle Database 10g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script creates the DHAMBY user and assigns the HRCLERK role

sqlplus dba1/oracle as sysdba <<EOF
DROP USER DHAMBY CASCADE;
create user dhamby identified by newuser profile hrprofile password expire;
grant connect, hrclerk to dhamby;
exit
EOF





